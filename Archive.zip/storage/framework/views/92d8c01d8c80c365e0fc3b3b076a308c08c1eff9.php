<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-16">
            <div class="card">
                <div class="card-header"><h1>Dashboard</h1></div>

                <div class="card-body">
<div class="row">
    <div style="margin: 10px;">
        <table>
            <h3>Guest</h3>
            <tr>
              <th>Customer</th>
              <th>Phone</th>
              <th>Email</th>
              <th>Arrival Date</th>
              <th>Departure Date</th>
              <th>Room(s)</th>
              <th>Guest(s)</th>
              <th>Note</th>
            </tr>
            <?php $__currentLoopData = $guest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th><?php echo e($guest->name); ?></th>
                <th><?php echo e($guest->phone); ?></th>
                <th><?php echo e($guest->email); ?></th>
                <th><?php echo e($guest->arrival); ?></th>
                <th><?php echo e($guest->departure); ?></th>
                <th><?php echo e($guest->room); ?></th>
                <th><?php echo e($guest->guest); ?></th>
                <th><?php echo e($guest->note); ?></th>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
</div>
<div class="row">
    <div style="margin: 10px;">
        <table>
            <h3>Premiere</h3>
            <tr>
              <th>Customer</th>
              <th>Phone</th>
              <th>Email</th>
              <th>Arrival Date</th>
              <th>Departure Date</th>
              <th>Room(s)</th>
              <th>Guest(s)</th>
              <th>Note</th>
            </tr>
            <?php $__currentLoopData = $premiere; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $premiere): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th><?php echo e($premiere->name); ?></th>
                <th><?php echo e($premiere->phone); ?></th>
                <th><?php echo e($premiere->email); ?></th>
                <th><?php echo e($premiere->arrival); ?></th>
                <th><?php echo e($premiere->departure); ?></th>
                <th><?php echo e($premiere->room); ?></th>
                <th><?php echo e($premiere->guest); ?></th>
                <th><?php echo e($premiere->note); ?></th>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
</div>


<div class="row">
    <div style="margin: 10px;">
        <table>
            <h3>Suite</h3>
            <tr>
              <th>Customer</th>
              <th>Phone</th>
              <th>Email</th>
              <th>Arrival Date</th>
              <th>Departure Date</th>
              <th>Room(s)</th>
              <th>Guest(s)</th>
              <th>Note</th>
            </tr>
            <?php $__currentLoopData = $suite; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $suite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th><?php echo e($suite->name); ?></th>
                <th><?php echo e($suite->phone); ?></th>
                <th><?php echo e($suite->email); ?></th>
                <th><?php echo e($suite->arrival); ?></th>
                <th><?php echo e($suite->departure); ?></th>
                <th><?php echo e($suite->room); ?></th>
                <th><?php echo e($suite->guest); ?></th>
                <th><?php echo e($suite->note); ?></th>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
</div>


</div>
</div>
</div>
</div>

</div>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><h2 >Reservation Form</h2></div>

                    <div class="card-body">
                        
          <form action="booking" method="POST">
            <div class="row">
                <div class="col-md-12 form-group">
                    <label for="type">Room Option</label>
                    <select name="type" id="type">
                        <option value="1">Guest Room</option>
                        <option value="2">Premiere Room</option>
                        <option value="3">Suite</option>
                    </select>
                </div>
            </div>

            <div class="row">
              <div class="col-md-12 form-group">
                  <label for="name">Full Name</label>
                    <div style="color:red"><?php echo e($errors->first('name')); ?> </div>
                    <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>"/>


                </div>
                </div>
                <div class="row">
                <div class="col-md-12 form-group">
                    <label for="phone">Phone</label>
                    <div style="color:red"><?php echo e($errors->first('phone')); ?></div>
                    <input type="tel" name="phone" class="form-control" value="<?php echo e(old('phone')); ?>"
                    />
                </div>
                </div>

                <div class="row">
                <div class="col-md-12 form-group">
                    <label for="email">Email</label>
                    <div style="color:red"><?php echo e($errors->first('email')); ?></div>
                    <input type="email" name="email"value="<?php echo e(old('email')); ?>"class="form-control" />
                </div>
                </div>
                <div class="row">
                <div class="col-sm-6 form-group">
                    <label for="">Arrival Date</label>
                    <div style="color:red"><?php echo e($errors->first('arrival')); ?></div>
                    <div style="position: relative;">
                    <span class="fa fa-calendar icon" style="position: absolute; right: 10px; top: 10px;"></span>
                    <input type="text" class="form-control" name="arrival"value="<?php echo e(old('ardate')); ?>" />
                    </div>
                </div>

                <div class="col-sm-6 form-group">
                    <label for="">Departure Date</label>
                    <div style="color:red"><?php echo e($errors->first('departure')); ?></div>
                    <div style="position: relative;">
                    <span class="fa fa-calendar icon" style="position: absolute; right: 10px; top: 10px;"></span>
                    <input type="text" class="form-control" name="departure"value="<?php echo e(old('dpdate')); ?>" />
                    </div>
                </div>
                </div>

                <div class="row">
                <div class="col-md-6 form-group">
                    <label for="room">Number of room</label>
                    <div style="color:red"><?php echo e($errors->first('noroom')); ?></div>
                    <select name="room" class="form-control">
                    <option value="1">1 Room</option>
                    <option value="2">2 Rooms</option>
                    <option value="3">3 Rooms</option>
                    <option value="4">4 Rooms</option>
                    </select>
                </div>

                <div class="col-md-6 form-group">
                    <label for="room">Guests (Max 8)</label>
                    <div style="color:red"><?php echo e($errors->first('noguest')); ?></div>
                    <select name="guest" class="form-control">
                        <option value="1">1 Guest</option>
                        <option value="2">2 Guests</option>
                        <option value="3">3 Guests</option>
                        <option value="4">4 Guests</option>
                        <option value="5">5 Guests</option>
                        <option value="6">6 Guests</option>
                        <option value="7">7 Guests</option>
                        <option value="8">8 Guests</option>
                    </select>
                </div>
                </div>
                <div class="row">
                <div class="col-md-12 form-group">
                    <label for="message">Write a Note</label>
                    <div style="color:red"><?php echo e($errors->first('note')); ?></div>
                    <textarea type="text" name="note" class="form-control" cols="30" rows="8" value="<?php echo e(old('note')); ?>"></textarea>
                </div>
                </div>
                <div class="row">
                <div class="col-md-6 form-group">
                    <input type="submit" value="Reserve Now" class="btn btn-primary" />
                </div>
                </div>

                <?php echo csrf_field(); ?>
            </form>

                    </div>
                </div>
            </div>
        </div>
        
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/phamcong/Desktop/1. LEARN/0. Coding/1. Web Project/Final PJ/LuxtelProject/resources/views/home.blade.php ENDPATH**/ ?>