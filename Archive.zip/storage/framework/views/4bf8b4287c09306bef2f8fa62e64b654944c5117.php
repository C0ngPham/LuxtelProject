<?php $__env->startSection('content'); ?>

<h1>Room Orders</h1>

<ul>
    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($order->name); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/phamcong/Desktop/1. LEARN/0. Coding/1. Web Project/Final PJ/LuxtelProject/resources/views/order.blade.php ENDPATH**/ ?>