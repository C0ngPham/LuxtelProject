@extends('layouts.app')

@section('content')
<h1>Admin Page</h1>
@endsection